
#include <stdio.h>

long long fibonnaci(long long);

int main() {

    printf("fibonnaci(8)=%lli\n", fibonnaci(8)); // 21
    printf("fibonnaci(-5)=%lli\n", fibonnaci(-5)); // -1
    return 0;
}






